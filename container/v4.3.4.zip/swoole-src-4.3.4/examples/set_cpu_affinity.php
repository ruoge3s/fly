<?php
swoole_process::setaffinity(array(0, 2));
sleep(1000);
